from flask import Flask, render_template, request, jsonify
from game_backend import WordChainGame  # Import the backend game logic

app = Flask(__name__)

# Initialize the game object
game = None

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/level_selection')
def level_selection():
    return render_template('index.html')

@app.route('/start', methods=['POST'])
def start_game():
    global game
    level = request.form.get('level')
    game = WordChainGame(level=level)
    return jsonify({'rules': game.rules, 'message': f'Game started at {level} level!'})

@app.route('/player_turn', methods=['POST'])
def player_turn():
    global game
    word = request.form.get('word').strip().lower()
    if not game:
        return jsonify({'error': 'No active game found! Start a new game first.'})

    # Validate player's word
    if not game.current_letter:
        valid = game.player_turn(word)
    else:
        if not word.startswith(game.current_letter):
            return jsonify({'error': f"Invalid word! Must start with '{game.current_letter}'."})

        valid = game.player_turn(word)

    if not valid:
        return jsonify({'error': 'Invalid word! Either used already or does not meet the rules.'})

    # AI's turn
    ai_word = game.ai_turn()
    if not ai_word:
        return jsonify({'message': 'You win! AI has no valid words left.', 'player_score': game.player_score, 'ai_score': game.ai_score, 'winner': 'player'})
    
    game.add_word(ai_word, 'ai')
    winner = game.check_winner()
    if winner:
        return jsonify({'message': f'{winner.capitalize()} wins!', 'player_score': game.player_score, 'ai_score': game.ai_score, 'winner': winner})

    return jsonify({
        'message': f'AI played: {ai_word}',
        'player_score': game.player_score,
        'ai_score': game.ai_score,
        'current_letter': game.current_letter
    })

if __name__ == '__main__':
    app.run(debug=True)
