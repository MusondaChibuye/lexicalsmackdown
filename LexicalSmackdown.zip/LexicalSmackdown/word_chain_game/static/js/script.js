function startGame(level) {
    fetch('/start', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `level=${level}`
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('rules').innerText = data.rules;
        document.getElementById('game-rules').style.display = 'none';
        document.getElementById('game-board').style.display = 'block';
        document.getElementById('turn-info').innerText = data.message;
        document.getElementById('feedback').innerText = '';
    });
}

function playerTurn() {
    const word = document.getElementById('word-input').value;
    if (!word) {
        alert("Please enter a word.");
        return;
    }

    fetch('/player_turn', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `word=${word}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            document.getElementById('feedback').innerText = data.error;
        } else {
            document.getElementById('turn-info').innerText = data.message;
            document.getElementById('player-score').innerText = data.player_score;
            document.getElementById('ai-score').innerText = data.ai_score;

            if (data.winner) {
                document.getElementById('game-board').style.display = 'none';
                document.getElementById('game-over').style.display = 'block';
                document.getElementById('winner-message').innerText = `${data.winner.toUpperCase()} wins the game!`;
            } else if (data.current_letter) {
                document.getElementById('word-input').placeholder = `Enter a word starting with '${data.current_letter}'`;
            }

            document.getElementById('word-input').value = '';
        }
    });
}

function restartGame() {
    // Reset the game to the main menu
    document.getElementById('game-board').style.display = 'none';
    document.getElementById('game-over').style.display = 'none';
    document.getElementById('game-rules').style.display = 'block';
    document.getElementById('rules').innerText = '';
}
