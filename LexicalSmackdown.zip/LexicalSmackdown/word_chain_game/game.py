import random
import time
import threading
import nltk
from nltk.corpus import wordnet as wn

# Helper functions and constants
VALIDATION_RULES = {
    "easy": {
        "min_length": 3,
        "max_length": None,  # No maximum length for the easy level
        "time_limit": None,
        "rules": "Rules: Use words with at least 3 letters. No time limit."
    },
    "normal": {
        "min_length": 5,
        "max_length": None,
        "time_limit": 30,
        "rules": "Rules: Use words with at least 5 letters. You have 30 seconds to respond."
    },
    "hard": {
        "min_length": 6,
        "max_length": None,
        "time_limit": 15,
        "rules": "Rules: Use words with at least 6 letters. You have 15 seconds to respond."
    }
}

def get_valid_words(current_letter, min_length, max_length, words, used_words):
    """Returns a list of valid words based on the current letter and level rules."""
    return [word for word in words if word.startswith(current_letter) and
            (min_length is None or len(word) >= min_length) and
            (max_length is None or len(word) <= max_length) and
            word not in used_words and " " not in word and "_" not in word and "-" not in word]

class WordChainGame:
    def __init__(self, level='easy'):
        self.words = set(wn.words())
        self.used_words = set()
        self.current_letter = ''
        self.player_score = 0
        self.ai_score = 0
        self.target_score = 75
        self.level = level
        self.failed_attempts = 0
        self.max_attempts = 3
        self.stop_timer = threading.Event()
        self.set_level_rules()

    def set_level_rules(self):
        """Set game rules based on the selected level."""
        rules = VALIDATION_RULES.get(self.level, VALIDATION_RULES['easy'])
        self.min_word_length = rules['min_length']
        self.max_word_length = rules['max_length']
        self.time_limit = rules['time_limit']
        self.rules = rules['rules']

    def validate_word(self, word):
        """Validate the word based on game rules."""
        word = word.lower()
        if (" " in word) or ("_" in word) or ("-" in word):
            return False

        if (self.min_word_length is None or len(word) >= self.min_word_length) and \
           (self.max_word_length is None or len(word) <= self.max_word_length) and \
           word in self.words and word not in self.used_words:
            return True
        return False

    def add_word(self, word, player):
        """Add word to the game and update scores."""
        self.used_words.add(word)
        self.current_letter = word[-1]
        word_length = len(word)
        if player == "player":
            self.player_score += word_length
        elif player == "ai":
            self.ai_score += word_length

    def ai_turn(self):
        """AI selects a valid word based on rules for the current level."""
        valid_words = get_valid_words(self.current_letter, self.min_word_length, self.max_word_length, self.words, self.used_words)
        if valid_words:
            return random.choice(valid_words)
        return None

    def player_turn(self, word):
        """Handle player's turn and validate their word."""
        if self.validate_word(word):
            self.add_word(word, "player")
            return True
        return False

    def check_winner(self):
        """Check if any player has reached the target score."""
        if self.player_score >= self.target_score:
            return "player"
        elif self.ai_score >= self.target_score:
            return "ai"
        return None

    def player_input(self, prompt):
        """Handle player input with a timer for levels with a time limit."""
        if self.time_limit:
            print(prompt, f"(You have {self.time_limit} seconds)")
            player_input = [None]

            def get_input():
                player_input[0] = input().strip().lower()
                self.stop_timer.set()

            self.stop_timer.clear()
            input_thread = threading.Thread(target=get_input)
            input_thread.start()
            input_thread.join(timeout=self.time_limit)

            if input_thread.is_alive():
                print("Time's up! You didn't enter a word in time.")
                return None
            return player_input[0]
        else:
            return input(prompt).strip().lower()

# Game management and flow
def play_game():
    """Main game loop handling player and AI interactions."""
    while True:
        level = input("Choose game level (easy, normal, hard): ").strip().lower()
        if level not in ['easy', 'normal', 'hard']:
            print("Invalid level selected, defaulting to 'easy'.")
            level = 'easy'

        game = WordChainGame(level)

        print(f"Level Selected: {level.capitalize()}")
        print(game.rules)

        # AI starts the game
        ai_word = game.ai_turn()
        if not ai_word:
            print("AI couldn't find a word. You win by default!")
            return
        
        print(f"AI starts the game with the word: {ai_word}")
        game.add_word(ai_word, "ai")
        print(f"AI's score: {game.ai_score}")

        while True:
            winner = game.check_winner()
            if winner:
                print(f"{winner.capitalize()} wins the game with {game.player_score if winner == 'player' else game.ai_score} points!")
                break

            if game.current_letter:
                player_word = game.player_input(f"Enter a word starting with '{game.current_letter}' (or 'quit' to exit): ")
                if player_word == 'quit':
                    print("Game over!")
                    break
                if not player_word or not player_word.startswith(game.current_letter):
                    game.failed_attempts += 1
                    print(f"Invalid word! The word must start with '{game.current_letter}'. Attempts left: {game.max_attempts - game.failed_attempts}")
                    if game.failed_attempts >= game.max_attempts:
                        print("You've exceeded the maximum number of attempts. Game over!")
                        break
                    continue
            else:
                player_word = game.player_input("Enter any word to start the game (or 'quit' to exit): ")
                if player_word == 'quit':
                    print("Game over!")
                    break

            if not player_word:
                game.failed_attempts += 1
                print(f"You didn't enter a word. Attempts left: {game.max_attempts - game.failed_attempts}")
                if game.failed_attempts >= game.max_attempts:
                    print("You've exceeded the maximum number of attempts. Game over!")
                    break
            elif len(player_word) < game.min_word_length:
                game.failed_attempts += 1
                print(f"Invalid word! The word must be at least {game.min_word_length} letters long. Attempts left: {game.max_attempts - game.failed_attempts}")
                if game.failed_attempts >= game.max_attempts:
                    print("You've exceeded the maximum number of attempts. Game over!")
                    break
            elif not game.player_turn(player_word):
                game.failed_attempts += 1
                print(f"Invalid word or word already used. Attempts left: {game.max_attempts - game.failed_attempts}")
                if game.failed_attempts >= game.max_attempts:
                    print("You've exceeded the maximum number of attempts. Game over!")
                    break
            else:
                game.failed_attempts = 0  # Reset failed attempts if the word is valid
                print(f"Your score: {game.player_score}")

                ai_word = game.ai_turn()
                if not ai_word:
                    print("AI has no valid words. You win!")
                    break
                print(f"AI's word: {ai_word}")
                game.add_word(ai_word, "ai")

                print(f"AI's score: {game.ai_score}")

        while True:
            choice = input("Do you want to play again? (yes/no): ").strip().lower()
            if choice in ['yes', 'no']:
                break
            print("Invalid choice. Please enter 'yes' or 'no'.")

        if choice == 'no':
            print("Thank you for playing! Goodbye.")
            break

if __name__ == "__main__":
    play_game()
