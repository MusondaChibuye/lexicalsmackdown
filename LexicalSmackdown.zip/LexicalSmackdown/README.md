# Lexical Smackdown

**Lexical Smackdown** is a word chain game where players take turns entering valid words that begin with the last letter of the previous word. The game supports single-player mode where the player competes against the AI. Players can select from three difficulty levels: Easy, Normal, and Hard.

## Features

- **Single-player mode**: Play against an AI opponent.
- **Three Difficulty Levels**:
  - **Easy**: No word length constraints, ideal for casual play.
  - **Normal**: Words must be at least 5 letters long.
  - **Hard**: Words must be at least 6 letters long.
- **Scoring System**: Points are assigned based on the length of the words. One point per letter, and the first to 75 points wins the game.
- **AI Word Generation**: The AI selects valid words based on the difficulty level.
- **Main Menu**: Players are returned to the main menu after a game ends.
- **Error Messages**: Players are notified when their word is invalid based on the game’s rules.
- **Responsive Front End**: The front end is implemented using Flask and displays the current word, scores, and game progress.

## Requirements

To run the game, you will need:

- **Python 3.7 or higher**
- **Flask**: Python web framework to serve the front end.
- **NLTK**: Natural Language Toolkit for processing and validating words.
- **pyenchant**: For word validation and dictionary support.

You can install the required dependencies with the following command:

```bash
pip install flask nltk pyenchant

Then run wordnet_test.py using the command python3 wordnet_test.py to download wordnet which is an essential library for the game.

## How to play
1.Clone this repository:
git clone https://github.com/username/lexicalsmackdown.git
2.Navigate to the project directory:
cd lexicalsmackdown
3.Run the game using Flask:
flask run
4.Open your web browser and go to:
http://127.0.0.1:5000
5.On the home page, click the Play button to begin.

##Game Instructions:
Easy Level: Enter any valid word with no length restrictions.
Normal Level: Enter words with at least 5 letters.
Hard Level: Enter words with at least 6 letters.
The game continues until one player reaches 75 points.

##How the Scoring System Works
1 point is awarded for each letter in the word you enter.
The first player (AI or human) to reach 75 points wins the game.
If you make an invalid move (e.g., a word that doesn't meet the length criteria), an error message will be displayed, and you must enter a valid word.

## Project Structure
app.py: The main Flask application file.
word_chain_backend.py: The core backend logic for the word chain game.
templates/: Contains HTML templates for the game UI.
static/css/styles.css: The stylesheet for the front-end design.

##License
This project is licensed under the MIT License.

